package dev.realweather.cm1;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Загрузка кадра CM1 (NetCDF classic, один файл на момент времени) в окно вокруг шторма.
 * Имена переменных настраиваются (по умолчанию типичные для CM1: qc, qi, qr, uinterp/vinterp/winterp, xh/yh/zh).
 * Ничего не выдумывается: если нужной переменной нет — понятная ошибка со списком имеющихся.
 */
public final class Cm1Loader {
    private Cm1Loader() {}

    public static final class Params {
        public String[] cloud = {"qc", "qi"};
        public String[] rain = {"qr"};
        public String[] u = {"uinterp", "u"};
        public String[] v = {"vinterp", "v"};
        public String[] w = {"winterp", "w"};
        public String xName = "xh", yName = "yh", zName = "zh", timeName = "time";
        public int windowCells = 128;
        public int stride = 1;
        public int maxLevels = 40;
        public double zTopKm = 18.0;
        public int trackMode = 0;            // 0 — максимум апдрафта, 1 — максимум приземной завихрённости
    }

    /** Текстовое описание файла (измерения, переменные) — для диагностики командой cm1 inspect. */
    public static String inspect(Path file) throws IOException {
        try (NetCdf nc = NetCdf.open(file)) {
            return nc.describe();
        }
    }

    private static List<String> present(NetCdf nc, String[] names) {
        List<String> r = new ArrayList<>();
        for (String n : names) if (nc.has(n.trim())) r.add(n.trim());
        return r;
    }

    private static String first(NetCdf nc, String[] names) {
        for (String n : names) if (nc.has(n.trim())) return n.trim();
        return null;
    }

    private static double[] coords(NetCdf nc, String name, int n, double fallbackStep) throws IOException {
        double[] r = new double[n];
        if (nc.has(name) && nc.shape(name).length == 1 && nc.shape(name)[0] >= n) {
            float[] f = nc.readAll(name, 0);
            for (int i = 0; i < n; i++) r[i] = f[i];
        } else {
            for (int i = 0; i < n; i++) r[i] = (i + 0.5) * fallbackStep;   // км
        }
        return r;
    }

    /** Читает «срез» переменной (k,y,x) c учётом сдвинутых сеток CM1 (u/v/w на гранях) — усредняет до центров ячеек. */
    private static void readInto(NetCdf nc, String var, int nz, int ny, int nx, int kCount, int x0, int y0,
                                 int outNx, int outNy, int stride, float[] dst, boolean add) throws IOException {
        int[] shp = nc.shape(var);
        int sz = shp[0] - nz, sy = shp[1] - ny, sx = shp[2] - nx;
        if (sz < 0 || sy < 0 || sx < 0 || sz > 1 || sy > 1 || sx > 1) {
            throw new IOException("Форма переменной " + var + " " + Arrays.toString(shp) + " не согласуется с сеткой "
                    + nz + "×" + ny + "×" + nx);
        }
        int span = (outNx - 1) * stride + 1 + sx;
        for (int k = 0; k < kCount; k++) {
            for (int jy = 0; jy < outNy; jy++) {
                int y = y0 + jy * stride;
                float[] row = null;
                int cnt = 0;
                for (int dk = 0; dk <= sz; dk++) {
                    for (int dy = 0; dy <= sy; dy++) {
                        float[] r = nc.read(var, 0, new int[]{Math.min(k + dk, shp[0] - 1), Math.min(y + dy, shp[1] - 1), x0},
                                new int[]{1, 1, Math.min(span, shp[2] - x0)});
                        if (row == null) row = r.clone();
                        else for (int i = 0; i < Math.min(row.length, r.length); i++) row[i] += r[i];
                        cnt++;
                    }
                }
                for (int ix = 0; ix < outNx; ix++) {
                    int xi = ix * stride;
                    float val = row[xi];
                    if (sx == 1) val = 0.5f * (row[xi] + row[Math.min(xi + 1, row.length - 1)]);
                    val /= cnt;
                    int idx = (k * outNy + jy) * outNx + ix;
                    dst[idx] = add ? dst[idx] + val : val;
                }
            }
        }
    }

    private static float[] level(NetCdf nc, String var, int k) throws IOException {
        int[] s = nc.shape(var);
        return nc.read(var, 0, new int[]{Math.min(k, s[0] - 1), 0, 0}, new int[]{1, s[1], s[2]});
    }

    public static Cm1Window load(Path file, Params p) throws IOException {
        try (NetCdf nc = NetCdf.open(file)) {
            List<String> cloudVars = present(nc, p.cloud);
            if (cloudVars.isEmpty()) {
                throw new IOException("В файле нет переменных облака " + Arrays.toString(p.cloud) + ". Есть: " + nc.varNames()
                        + ". Включите вывод qc/qi в namelist.input CM1 или поменяйте имена в конфиге.");
            }
            List<String> rainVars = present(nc, p.rain);
            String uN = first(nc, p.u), vN = first(nc, p.v), wN = first(nc, p.w);
            int[] cs = nc.shape(cloudVars.get(0));
            if (cs.length != 3) throw new IOException("Переменная " + cloudVars.get(0) + " не 3-мерная: " + Arrays.toString(cs));
            int nz = cs[0], ny = cs[1], nx = cs[2];

            // координаты (км → м; если значения высоты > 60, считаем что уже метры)
            double[] xr = coords(nc, p.xName, nx, 1.0), yr = coords(nc, p.yName, ny, 1.0), zr = coords(nc, p.zName, nz, 0.5);
            double fac = zr[nz - 1] > 60.0 ? 1.0 : 1000.0;
            double[] xm = new double[nx], ym = new double[ny], zm = new double[nz];
            for (int i = 0; i < nx; i++) xm[i] = xr[i] * fac;
            for (int i = 0; i < ny; i++) ym[i] = yr[i] * fac;
            for (int i = 0; i < nz; i++) zm[i] = zr[i] * fac;
            double dx = nx > 1 ? (xm[nx - 1] - xm[0]) / (nx - 1) : 1000.0;
            double dy = ny > 1 ? (ym[ny - 1] - ym[0]) / (ny - 1) : 1000.0;

            // ---- слежение: центр окна
            int cxi = nx / 2, cyi = ny / 2;
            boolean found = false;
            if (p.trackMode == 1 && uN != null && vN != null) {
                float[] su = level(nc, uN, 0), sv = level(nc, vN, 0);
                int unx = nc.shape(uN)[2], vnx = nc.shape(vN)[2];
                double best = -1;
                for (int j = 1; j < ny - 1; j++) {
                    for (int i = 1; i < nx - 1; i++) {
                        double dvdx = (sv[j * vnx + Math.min(i + 1, vnx - 1)] - sv[j * vnx + i - 1]) / (2 * dx);
                        double dudy = (su[Math.min(j + 1, nc.shape(uN)[1] - 1) * unx + i] - su[(j - 1) * unx + i]) / (2 * dy);
                        double z = Math.abs(dvdx - dudy);
                        if (z > best) { best = z; cxi = i; cyi = j; }
                    }
                }
                found = best >= 0;
            }
            if (!found && wN != null) {
                int[] ws = nc.shape(wN);
                int k = Math.min(ws[0] - 1, Math.round(0.3f * (ws[0] - 1)));
                float[] w = level(nc, wN, k);
                int best = 0;
                for (int i = 1; i < w.length; i++) if (w[i] > w[best]) best = i;
                cxi = Math.min(best % ws[2], nx - 1);
                cyi = Math.min(best / ws[2], ny - 1);
                found = true;
            }
            if (!found) {
                float[] col = new float[ny * nx];
                String cv = cloudVars.get(0);
                for (int k = 0; k < nz; k++) {
                    float[] l = level(nc, cv, k);
                    for (int i = 0; i < col.length; i++) col[i] += l[i];
                }
                int best = 0;
                for (int i = 1; i < col.length; i++) if (col[i] > col[best]) best = i;
                cxi = best % nx;
                cyi = best / nx;
            }

            // ---- окно
            int stride = Math.max(1, p.stride);
            int outNx = Math.max(1, Math.min(p.windowCells, nx / stride));
            int outNy = Math.max(1, Math.min(p.windowCells, ny / stride));
            int spanX = outNx * stride, spanY = outNy * stride;
            int x0 = Math.max(0, Math.min(cxi - spanX / 2, nx - spanX));
            int y0 = Math.max(0, Math.min(cyi - spanY / 2, ny - spanY));

            int kTop = nz - 1;
            for (int k = 0; k < nz; k++) if (zm[k] <= p.zTopKm * 1000.0) kTop = k;
            int kCount = Math.max(2, Math.min(nz, kTop + 1));
            int nzOut = Math.max(2, Math.min(p.maxLevels, kCount));
            double zTop = Math.max(zm[kCount - 1], 1.0);

            int cells = kCount * outNy * outNx;
            float[] srcCloud = new float[cells], srcRain = new float[cells];
            float[] srcU = new float[cells], srcV = new float[cells], srcW = new float[cells];
            for (String cv : cloudVars) readInto(nc, cv, nz, ny, nx, kCount, x0, y0, outNx, outNy, stride, srcCloud, true);
            for (String rv : rainVars) readInto(nc, rv, nz, ny, nx, kCount, x0, y0, outNx, outNy, stride, srcRain, true);
            if (uN != null) readInto(nc, uN, nz, ny, nx, kCount, x0, y0, outNx, outNy, stride, srcU, false);
            if (vN != null) readInto(nc, vN, nz, ny, nx, kCount, x0, y0, outNx, outNy, stride, srcV, false);
            if (wN != null) readInto(nc, wN, nz, ny, nx, kCount, x0, y0, outNx, outNy, stride, srcW, false);

            // ---- вертикальная передискретизация на равномерную сетку
            int[] k0 = new int[nzOut], k1 = new int[nzOut];
            float[] wt = new float[nzOut];
            for (int j = 0; j < nzOut; j++) {
                double z = (j + 0.5) / nzOut * zTop;
                int k = 0;
                while (k < kCount - 2 && zm[k + 1] <= z) k++;
                k0[j] = k;
                k1[j] = Math.min(k + 1, kCount - 1);
                double span = zm[k1[j]] - zm[k0[j]];
                wt[j] = span > 0 ? (float) Math.max(0, Math.min(1, (z - zm[k0[j]]) / span)) : 0f;
            }
            int plane = outNy * outNx;
            float[] cloud = new float[nzOut * plane], rain = new float[nzOut * plane];
            float[] u = new float[nzOut * plane], v = new float[nzOut * plane], w = new float[nzOut * plane];
            for (int j = 0; j < nzOut; j++) {
                for (int c = 0; c < plane; c++) {
                    int a = k0[j] * plane + c, b = k1[j] * plane + c, o = j * plane + c;
                    float t = wt[j];
                    cloud[o] = srcCloud[a] + (srcCloud[b] - srcCloud[a]) * t;
                    rain[o] = srcRain[a] + (srcRain[b] - srcRain[a]) * t;
                    u[o] = srcU[a] + (srcU[b] - srcU[a]) * t;
                    v[o] = srcV[a] + (srcV[b] - srcV[a]) * t;
                    w[o] = srcW[a] + (srcW[b] - srcW[a]) * t;
                }
            }

            // ---- радар: композитная отражаемость из дождевой воды (Ze = 3.63e9 (ρ·qr)^1.75), ветер у земли
            float[] refl = new float[plane], sfcU = new float[plane], sfcV = new float[plane];
            for (int j = 0; j < nzOut; j++) {
                double zc = (j + 0.5) / nzOut * zTop;
                double rho = 1.2 * Math.exp(-zc / 8000.0);
                for (int c = 0; c < plane; c++) {
                    double rq = rain[j * plane + c] * rho;
                    if (rq > 1e-9) {
                        double dbz = 10.0 * Math.log10(3.63e9 * Math.pow(rq, 1.75));
                        if (dbz > refl[c]) refl[c] = (float) dbz;
                    }
                }
            }
            System.arraycopy(srcU, 0, sfcU, 0, plane);
            System.arraycopy(srcV, 0, sfcV, 0, plane);

            // ---- торнадо: максимум приземной вертикальной завихрённости + сильный ветер рядом
            boolean tor = false;
            double torX = 0, torY = 0;
            float torWind = 0f, torZeta = 0f;
            double dxw = dx * stride, dyw = dy * stride;
            for (int j = 1; j < outNy - 1; j++) {
                for (int i = 1; i < outNx - 1; i++) {
                    double z = (sfcV[j * outNx + i + 1] - sfcV[j * outNx + i - 1]) / (2 * dxw)
                            - (sfcU[(j + 1) * outNx + i] - sfcU[(j - 1) * outNx + i]) / (2 * dyw);
                    if (z > torZeta) {
                        torZeta = (float) z;
                        torX = xm[x0] + (i + 0.5) * dxw - 0.5 * dxw;
                        torY = ym[y0] + (j + 0.5) * dyw - 0.5 * dyw;
                    }
                }
            }
            if (torZeta > 0f) {
                int ci = (int) Math.round((torX - xm[x0]) / dxw), cj = (int) Math.round((torY - ym[y0]) / dyw);
                for (int j = Math.max(0, cj - 3); j <= Math.min(outNy - 1, cj + 3); j++) {
                    for (int i = Math.max(0, ci - 3); i <= Math.min(outNx - 1, ci + 3); i++) {
                        float sp = (float) Math.hypot(sfcU[j * outNx + i], sfcV[j * outNx + i]);
                        if (sp > torWind) torWind = sp;
                    }
                }
                tor = torZeta > 0.04f && torWind > 25f;
            }

            double simTime = 0;
            if (nc.has(p.timeName)) {
                float[] t = nc.read(p.timeName, 0, new int[0], new int[0]);
                if (t.length > 0) simTime = t[0];
            }
            double cxm = xm[Math.min(nx - 1, cxi)], cym = ym[Math.min(ny - 1, cyi)];
            return new Cm1Window(outNx, outNy, nzOut, cloud, rain, u, v, w, refl, sfcU, sfcV,
                    xm[x0] - 0.5 * dx, ym[y0] - 0.5 * dy, dxw, dyw, zTop, simTime, tor, torX, torY, torWind, torZeta, cxm, cym);
        }
    }
}
