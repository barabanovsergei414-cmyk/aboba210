package dev.realweather.cm1;

/** Перевод координат CM1 (метры) в блоки мира: горизонтальный и вертикальный масштаб независимы. */
public final class Cm1Mapping {
    public final double anchorX, anchorZ;      // позиция в мире (блоки), соответствующая domAnchor
    public final double domAnchorXm, domAnchorYm;
    public final double groundY;
    public final double mpbH, mpbV;            // метров на блок по горизонтали / вертикали

    public Cm1Mapping(double anchorX, double anchorZ, double domAnchorXm, double domAnchorYm,
                      double groundY, double mpbH, double mpbV) {
        this.anchorX = anchorX; this.anchorZ = anchorZ;
        this.domAnchorXm = domAnchorXm; this.domAnchorYm = domAnchorYm;
        this.groundY = groundY; this.mpbH = mpbH; this.mpbV = mpbV;
    }

    public double worldX(double xm) { return anchorX + (xm - domAnchorXm) / mpbH; }

    public double worldZ(double ym) { return anchorZ + (ym - domAnchorYm) / mpbH; }

    public double worldY(double zm) { return groundY + zm / mpbV; }

    public double domX(double wx) { return domAnchorXm + (wx - anchorX) * mpbH; }

    public double domY(double wz) { return domAnchorYm + (wz - anchorZ) * mpbH; }
}
