package dev.realweather.cm1;

/**
 * Снимок поля CM1 в окне вокруг шторма: облачная вода, дождь, скорость ветра и производные (радар, торнадо).
 * Индекс ячейки: (k * ny + j) * nx + i, где i — x, j — y, k — высота. Все единицы СИ (кг/кг, м/с), координаты окна — метры домена.
 */
public final class Cm1Window {
    public final int nx, ny, nz;
    public final float[] cloud, rain, u, v, w;
    public final float[] refl;                 // композитная отражаемость, dBZ (ny*nx)
    public final float[] sfcU, sfcV;           // ветер у земли (ny*nx)
    public final double x0m, y0m, dxm, dym, zTopm;
    public final double simTime;
    public final boolean tornado;
    public final double torXm, torYm;
    public final float torWind, torZeta;
    public final double centerXm, centerYm;    // центр слежения (апдрафт / торнадо)
    private volatile Cm1Mapping map;
    public volatile long version;

    public Cm1Window(int nx, int ny, int nz, float[] cloud, float[] rain, float[] u, float[] v, float[] w,
                     float[] refl, float[] sfcU, float[] sfcV, double x0m, double y0m, double dxm, double dym,
                     double zTopm, double simTime, boolean tornado, double torXm, double torYm,
                     float torWind, float torZeta, double centerXm, double centerYm) {
        this.nx = nx; this.ny = ny; this.nz = nz;
        this.cloud = cloud; this.rain = rain; this.u = u; this.v = v; this.w = w;
        this.refl = refl; this.sfcU = sfcU; this.sfcV = sfcV;
        this.x0m = x0m; this.y0m = y0m; this.dxm = dxm; this.dym = dym; this.zTopm = zTopm;
        this.simTime = simTime; this.tornado = tornado; this.torXm = torXm; this.torYm = torYm;
        this.torWind = torWind; this.torZeta = torZeta; this.centerXm = centerXm; this.centerYm = centerYm;
    }

    public void setMapping(Cm1Mapping m) { this.map = m; }

    public Cm1Mapping mapping() { return map; }

    // границы окна в мире (блоки); y — абсолютная высота
    public double minX() { return map.worldX(x0m); }
    public double maxX() { return map.worldX(x0m + nx * dxm); }
    public double minZ() { return map.worldZ(y0m); }
    public double maxZ() { return map.worldZ(y0m + ny * dym); }
    public double minY() { return map.worldY(0.0); }
    public double maxY() { return map.worldY(zTopm); }

    public boolean contains(double wx, double wy, double wz) {
        return wx >= minX() && wx <= maxX() && wz >= minZ() && wz <= maxZ() && wy >= minY() && wy <= maxY();
    }

    private static double clamp(double v, double lo, double hi) { return v < lo ? lo : (v > hi ? hi : v); }

    private static float tri(float[] f, int nx, int ny, int nz, double fx, double fy, double fz) {
        fx = clamp(fx, 0, nx - 1); fy = clamp(fy, 0, ny - 1); fz = clamp(fz, 0, nz - 1);
        int i0 = (int) fx, j0 = (int) fy, k0 = (int) fz;
        int i1 = Math.min(i0 + 1, nx - 1), j1 = Math.min(j0 + 1, ny - 1), k1 = Math.min(k0 + 1, nz - 1);
        double tx = fx - i0, ty = fy - j0, tz = fz - k0;
        double c00 = f[(k0 * ny + j0) * nx + i0] * (1 - tx) + f[(k0 * ny + j0) * nx + i1] * tx;
        double c10 = f[(k0 * ny + j1) * nx + i0] * (1 - tx) + f[(k0 * ny + j1) * nx + i1] * tx;
        double c01 = f[(k1 * ny + j0) * nx + i0] * (1 - tx) + f[(k1 * ny + j0) * nx + i1] * tx;
        double c11 = f[(k1 * ny + j1) * nx + i0] * (1 - tx) + f[(k1 * ny + j1) * nx + i1] * tx;
        double a = c00 * (1 - ty) + c10 * ty, b = c01 * (1 - ty) + c11 * ty;
        return (float) (a * (1 - tz) + b * tz);
    }

    private static float bil(float[] f, int nx, int ny, double fx, double fy) {
        fx = clamp(fx, 0, nx - 1); fy = clamp(fy, 0, ny - 1);
        int i0 = (int) fx, j0 = (int) fy, i1 = Math.min(i0 + 1, nx - 1), j1 = Math.min(j0 + 1, ny - 1);
        double tx = fx - i0, ty = fy - j0;
        double a = f[j0 * nx + i0] * (1 - tx) + f[j0 * nx + i1] * tx;
        double b = f[j1 * nx + i0] * (1 - tx) + f[j1 * nx + i1] * tx;
        return (float) (a * (1 - ty) + b * ty);
    }

    /** Координаты ячейки (непрерывные) для точки мира. */
    private double cx(double wx) { return (wx - minX()) / (maxX() - minX()) * nx - 0.5; }

    private double cy(double wz) { return (wz - minZ()) / (maxZ() - minZ()) * ny - 0.5; }

    private double cz(double wy) { return (wy - minY()) / (maxY() - minY()) * nz - 0.5; }

    /** Заполняет out = {cloud, rain, u, v, w}; возвращает false, если точка вне окна. */
    public boolean sample(double wx, double wy, double wz, double[] out) {
        if (!contains(wx, wy, wz)) return false;
        double fx = cx(wx), fy = cy(wz), fz = cz(wy);
        out[0] = tri(cloud, nx, ny, nz, fx, fy, fz);
        out[1] = tri(rain, nx, ny, nz, fx, fy, fz);
        out[2] = tri(u, nx, ny, nz, fx, fy, fz);
        out[3] = tri(v, nx, ny, nz, fx, fy, fz);
        out[4] = tri(w, nx, ny, nz, fx, fy, fz);
        return true;
    }

    /** Ветер (м/с) в точке мира. Возвращает false вне окна. */
    public boolean wind(double wx, double wy, double wz, double[] outUvw) {
        if (!contains(wx, wy, wz)) return false;
        double fx = cx(wx), fy = cy(wz), fz = cz(wy);
        outUvw[0] = tri(u, nx, ny, nz, fx, fy, fz);
        outUvw[1] = tri(v, nx, ny, nz, fx, fy, fz);
        outUvw[2] = tri(w, nx, ny, nz, fx, fy, fz);
        return true;
    }

    /** Композитная отражаемость в dBZ; 0 вне окна. */
    public float reflAt(double wx, double wz) {
        if (wx < minX() || wx > maxX() || wz < minZ() || wz > maxZ()) return 0f;
        return bil(refl, nx, ny, cx(wx), cy(wz));
    }

    /** Приземный ветер (u,v) в м/с; false вне окна. */
    public boolean surfaceWind(double wx, double wz, double[] outUv) {
        if (wx < minX() || wx > maxX() || wz < minZ() || wz > maxZ()) return false;
        outUv[0] = bil(sfcU, nx, ny, cx(wx), cy(wz));
        outUv[1] = bil(sfcV, nx, ny, cx(wx), cy(wz));
        return true;
    }

    /** Интеграл облачной воды по колонке над точкой (кг/кг·уровни) — для затемнения неба под штормом. */
    public float cloudPathAt(double wx, double wz) {
        if (wx < minX() || wx > maxX() || wz < minZ() || wz > maxZ()) return 0f;
        int i = (int) clamp(Math.floor(cx(wx) + 0.5), 0, nx - 1), j = (int) clamp(Math.floor(cy(wz) + 0.5), 0, ny - 1);
        float sum = 0f;
        for (int k = 0; k < nz; k++) sum += cloud[(k * ny + j) * nx + i];
        return sum;
    }

    /** Дождевая вода у земли (кг/кг) над точкой. */
    public float lowRainAt(double wx, double wz) {
        if (wx < minX() || wx > maxX() || wz < minZ() || wz > maxZ()) return 0f;
        int i = (int) clamp(Math.floor(cx(wx) + 0.5), 0, nx - 1), j = (int) clamp(Math.floor(cy(wz) + 0.5), 0, ny - 1);
        return rain[j * nx + i];
    }

    /** Мировые координаты торнадо (если найдено). */
    public double torWorldX() { return map.worldX(torXm); }

    public double torWorldZ() { return map.worldZ(torYm); }

    /** Линейное смешение кадров: сетка берётся от a, значения b интерполируются по мировым координатам. */
    public static Cm1Window blend(Cm1Window a, Cm1Window b, float t) {
        if (t <= 0f) return a;
        if (t >= 1f) return b;
        Cm1Mapping m = a.map;
        int nx = a.nx, ny = a.ny, nz = a.nz;
        float[] cl = new float[a.cloud.length], rn = new float[a.rain.length];
        float[] uu = new float[a.u.length], vv = new float[a.v.length], ww = new float[a.w.length];
        float[] rf = new float[a.refl.length], su = new float[a.sfcU.length], sv = new float[a.sfcV.length];
        boolean same = a.x0m == b.x0m && a.y0m == b.y0m && a.dxm == b.dxm && a.dym == b.dym && a.nx == b.nx
                && a.ny == b.ny && a.nz == b.nz && a.zTopm == b.zTopm;
        double[] tmp = new double[5];
        double[] t2 = new double[2];
        double sx = (a.maxX() - a.minX()) / nx, sz = (a.maxZ() - a.minZ()) / ny, sy = (a.maxY() - a.minY()) / nz;
        for (int k = 0; k < nz; k++) {
            double wy = a.minY() + (k + 0.5) * sy;
            for (int j = 0; j < ny; j++) {
                double wz = a.minZ() + (j + 0.5) * sz;
                for (int i = 0; i < nx; i++) {
                    int idx = (k * ny + j) * nx + i;
                    if (same) {
                        cl[idx] = a.cloud[idx] + (b.cloud[idx] - a.cloud[idx]) * t;
                        rn[idx] = a.rain[idx] + (b.rain[idx] - a.rain[idx]) * t;
                        uu[idx] = a.u[idx] + (b.u[idx] - a.u[idx]) * t;
                        vv[idx] = a.v[idx] + (b.v[idx] - a.v[idx]) * t;
                        ww[idx] = a.w[idx] + (b.w[idx] - a.w[idx]) * t;
                    } else {
                        double wx = a.minX() + (i + 0.5) * sx;
                        boolean in = b.sample(wx, wy, wz, tmp);
                        cl[idx] = a.cloud[idx] + ((in ? (float) tmp[0] : 0f) - a.cloud[idx]) * t;
                        rn[idx] = a.rain[idx] + ((in ? (float) tmp[1] : 0f) - a.rain[idx]) * t;
                        uu[idx] = a.u[idx] + ((in ? (float) tmp[2] : a.u[idx]) - a.u[idx]) * t;
                        vv[idx] = a.v[idx] + ((in ? (float) tmp[3] : a.v[idx]) - a.v[idx]) * t;
                        ww[idx] = a.w[idx] + ((in ? (float) tmp[4] : a.w[idx]) - a.w[idx]) * t;
                    }
                }
            }
        }
        for (int j = 0; j < ny; j++) {
            double wz = a.minZ() + (j + 0.5) * sz;
            for (int i = 0; i < nx; i++) {
                int idx = j * nx + i;
                double wx = a.minX() + (i + 0.5) * sx;
                float rb = same ? b.refl[idx] : b.reflAt(wx, wz);
                rf[idx] = a.refl[idx] + (rb - a.refl[idx]) * t;
                if (same) {
                    su[idx] = a.sfcU[idx] + (b.sfcU[idx] - a.sfcU[idx]) * t;
                    sv[idx] = a.sfcV[idx] + (b.sfcV[idx] - a.sfcV[idx]) * t;
                } else if (b.surfaceWind(wx, wz, t2)) {
                    su[idx] = a.sfcU[idx] + ((float) t2[0] - a.sfcU[idx]) * t;
                    sv[idx] = a.sfcV[idx] + ((float) t2[1] - a.sfcV[idx]) * t;
                } else {
                    su[idx] = a.sfcU[idx];
                    sv[idx] = a.sfcV[idx];
                }
            }
        }
        Cm1Window src = t < 0.5f ? a : b;
        Cm1Window r = new Cm1Window(nx, ny, nz, cl, rn, uu, vv, ww, rf, su, sv, a.x0m, a.y0m, a.dxm, a.dym, a.zTopm,
                a.simTime + (b.simTime - a.simTime) * t, src.tornado, src.torXm, src.torYm, src.torWind, src.torZeta,
                src.centerXm, src.centerYm);
        r.setMapping(m);
        return r;
    }
}
