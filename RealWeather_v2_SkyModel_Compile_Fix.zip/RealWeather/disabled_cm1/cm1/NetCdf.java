package dev.realweather.cm1;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Минимальный читатель NetCDF classic (CDF-1 и CDF-2/64-bit offset) без внешних библиотек.
 * NetCDF-4/HDF5 и CDF-5 НЕ поддерживаются — для них выдаётся понятная ошибка.
 */
public final class NetCdf implements AutoCloseable {
    public static final class Dim {
        public final String name;
        public final long len;
        public final boolean unlimited;

        Dim(String name, long len, boolean unlimited) { this.name = name; this.len = len; this.unlimited = unlimited; }
    }

    public static final class Var {
        public final String name;
        public final int type;
        public final int[] dimIds;
        public final long begin;
        public final long vsize;
        public final boolean record;

        Var(String name, int type, int[] dimIds, long begin, long vsize, boolean record) {
            this.name = name; this.type = type; this.dimIds = dimIds; this.begin = begin; this.vsize = vsize; this.record = record;
        }
    }

    private final RandomAccessFile raf;
    private final FileChannel ch;
    private final List<Dim> dims = new ArrayList<>();
    private final Map<String, Var> vars = new LinkedHashMap<>();
    private long numRecs;
    private long recSize;
    private boolean cdf2;
    private ByteBuffer hdr;

    private NetCdf(RandomAccessFile raf) {
        this.raf = raf;
        this.ch = raf.getChannel();
    }

    public static NetCdf open(Path path) throws IOException {
        RandomAccessFile raf = new RandomAccessFile(path.toFile(), "r");
        NetCdf nc = new NetCdf(raf);
        try {
            nc.parse();
        } catch (IOException | RuntimeException e) {
            raf.close();
            throw e instanceof IOException io ? io : new IOException("Повреждённый или неподдерживаемый NetCDF: " + e, e);
        }
        return nc;
    }

    public Set<String> varNames() { return vars.keySet(); }

    public boolean has(String name) { return vars.containsKey(name); }

    public List<Dim> dims() { return dims; }

    public Var var(String name) { return vars.get(name); }

    public long numRecords() { return numRecs; }

    /** Длины измерений переменной БЕЗ записного (unlimited) измерения. */
    public int[] shape(String name) {
        Var v = vars.get(name);
        if (v == null) throw new IllegalArgumentException("нет переменной " + name);
        int skip = v.record ? 1 : 0;
        int[] s = new int[v.dimIds.length - skip];
        for (int i = skip; i < v.dimIds.length; i++) s[i - skip] = (int) dims.get(v.dimIds[i]).len;
        return s;
    }

    public String describe() {
        StringBuilder sb = new StringBuilder();
        sb.append(cdf2 ? "NetCDF classic (64-bit offset)" : "NetCDF classic").append(", записей по времени: ").append(numRecs).append('\n');
        sb.append("Измерения:");
        for (Dim d : dims) sb.append(' ').append(d.name).append('=').append(d.unlimited ? "unlimited(" + numRecs + ")" : String.valueOf(d.len));
        sb.append("\nПеременные:\n");
        for (Var v : vars.values()) {
            sb.append("  ").append(v.name).append('(');
            for (int i = 0; i < v.dimIds.length; i++) sb.append(i > 0 ? "," : "").append(dims.get(v.dimIds[i]).name);
            sb.append(")\n");
        }
        return sb.toString();
    }

    // ------------------------------------------------------------------ чтение данных

    private static int elemSize(int type) {
        return switch (type) {
            case 1, 2 -> 1;
            case 3 -> 2;
            case 4, 5 -> 4;
            case 6 -> 8;
            default -> throw new IllegalArgumentException("неизвестный тип NetCDF " + type);
        };
    }

    /**
     * Читает прямоугольный блок переменной (без записного измерения) из записи rec.
     * start/count — по измерениям из shape(name). Для скаляра передайте пустые массивы.
     */
    public float[] read(String name, int rec, int[] start, int[] count) throws IOException {
        Var v = vars.get(name);
        if (v == null) throw new IOException("нет переменной " + name);
        int[] shape = shape(name);
        int nd = shape.length;
        if (start.length != nd || count.length != nd) throw new IOException("неверная размерность запроса для " + name);
        for (int i = 0; i < nd; i++) {
            if (start[i] < 0 || count[i] < 0 || start[i] + count[i] > shape[i]) {
                throw new IOException("выход за границы " + name + " по оси " + i + ": " + start[i] + "+" + count[i] + " > " + shape[i]);
            }
        }
        int es = elemSize(v.type);
        long base = v.begin + (v.record ? (long) rec * recSize : 0L);
        long[] stride = new long[nd];
        long acc = 1;
        for (int i = nd - 1; i >= 0; i--) { stride[i] = acc; acc *= shape[i]; }
        long total = 1;
        for (int c : count) total *= c;
        if (total > Integer.MAX_VALUE) throw new IOException("слишком большой блок");
        float[] out = new float[(int) total];
        if (total == 0) return out;
        int rowLen = nd == 0 ? 1 : count[nd - 1];
        ByteBuffer buf = ByteBuffer.allocate(rowLen * es).order(ByteOrder.BIG_ENDIAN);
        int outer = Math.max(nd - 1, 0);
        int[] idx = new int[outer];
        int o = 0;
        while (true) {
            long off = 0;
            for (int i = 0; i < outer; i++) off += (long) (start[i] + idx[i]) * stride[i];
            if (nd > 0) off += (long) start[nd - 1] * stride[nd - 1];
            buf.clear();
            int want = rowLen * es;
            long pos = base + off * es;
            int got = 0;
            while (got < want) {
                int r = ch.read(buf, pos + got);
                if (r < 0) throw new IOException("неожиданный конец файла (" + name + ")");
                got += r;
            }
            buf.flip();
            for (int e = 0; e < rowLen; e++) {
                out[o++] = switch (v.type) {
                    case 1 -> buf.get();
                    case 3 -> buf.getShort();
                    case 4 -> buf.getInt();
                    case 5 -> buf.getFloat();
                    case 6 -> (float) buf.getDouble();
                    default -> buf.get();
                };
            }
            int d = outer - 1;
            while (d >= 0) {
                if (++idx[d] < count[d]) break;
                idx[d] = 0;
                d--;
            }
            if (d < 0) break;
        }
        return out;
    }

    /** Читает переменную целиком (без записного измерения). */
    public float[] readAll(String name, int rec) throws IOException {
        int[] s = shape(name);
        return read(name, rec, new int[s.length], s);
    }

    @Override
    public void close() throws IOException { raf.close(); }

    // ------------------------------------------------------------------ разбор заголовка

    private int i32() { return hdr.getInt(); }

    private long i64() { return hdr.getLong(); }

    private String name() {
        int len = i32();
        if (len < 0 || len > 4096) throw new IllegalStateException("плохая длина имени");
        byte[] b = new byte[len];
        hdr.get(b);
        int pad = (4 - (len & 3)) & 3;
        hdr.position(hdr.position() + pad);
        return new String(b, StandardCharsets.UTF_8);
    }

    private void skipAttrs() {
        int tag = i32();
        int n = i32();
        if (tag == 0 && n == 0) return;
        if (tag != 0x0C) throw new IllegalStateException("ожидался список атрибутов");
        for (int a = 0; a < n; a++) {
            name();
            int type = i32();
            int cnt = i32();
            long bytes = (long) cnt * elemSize(type);
            bytes = (bytes + 3) & ~3L;
            hdr.position((int) (hdr.position() + bytes));
        }
    }

    private void parse() throws IOException {
        long size = ch.size();
        int n = (int) Math.min(size, 16L << 20);
        hdr = ByteBuffer.allocate(n).order(ByteOrder.BIG_ENDIAN);
        int got = 0;
        while (got < n) {
            int r = ch.read(hdr, got);
            if (r < 0) break;
            got += r;
        }
        hdr.flip();
        if (hdr.remaining() < 8) throw new IOException("файл слишком короткий");
        int m0 = hdr.get() & 0xFF, m1 = hdr.get() & 0xFF, m2 = hdr.get() & 0xFF, ver = hdr.get() & 0xFF;
        if (m0 == 0x89 && m1 == 'H' && m2 == 'D') {
            throw new IOException("Это NetCDF-4/HDF5. Поддерживается только классический NetCDF: пересоберите CM1 с классическим NetCDF "
                    + "или конвертируйте файлы: nccopy -k classic in.nc out.nc");
        }
        if (m0 != 'C' || m1 != 'D' || m2 != 'F') throw new IOException("Это не NetCDF (нет сигнатуры CDF)");
        if (ver == 1) cdf2 = false;
        else if (ver == 2) cdf2 = true;
        else throw new IOException("Версия формата CDF-" + ver + " не поддерживается (нужен CDF-1 или CDF-2)");
        long nr = i32() & 0xFFFFFFFFL;
        numRecs = nr == 0xFFFFFFFFL ? 0 : nr;

        int tag = i32();
        int cnt = i32();
        int unlimitedId = -1;
        if (!(tag == 0 && cnt == 0)) {
            if (tag != 0x0A) throw new IOException("ожидался список измерений");
            for (int i = 0; i < cnt; i++) {
                String nm = name();
                long len = i32() & 0xFFFFFFFFL;
                boolean unl = len == 0;
                if (unl) unlimitedId = i;
                dims.add(new Dim(nm, unl ? numRecs : len, unl));
            }
        }
        skipAttrs();                                  // глобальные атрибуты

        tag = i32();
        cnt = i32();
        recSize = 0;
        if (!(tag == 0 && cnt == 0)) {
            if (tag != 0x0B) throw new IOException("ожидался список переменных");
            for (int i = 0; i < cnt; i++) {
                String nm = name();
                int nd = i32();
                int[] ids = new int[nd];
                for (int d = 0; d < nd; d++) ids[d] = i32();
                skipAttrs();
                int type = i32();
                long vsize = i32() & 0xFFFFFFFFL;
                long begin = cdf2 ? i64() : (i32() & 0xFFFFFFFFL);
                boolean rec = nd > 0 && ids[0] == unlimitedId && unlimitedId >= 0;
                if (rec) recSize += vsize;
                vars.put(nm, new Var(nm, type, ids, begin, vsize, rec));
            }
        }
        hdr = null;
    }
}
