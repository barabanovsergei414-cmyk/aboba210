package dev.realweather.client;

import dev.realweather.RealWeather;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;

/** Собственные звуки мода (файлы в assets/realweather/sounds, описание — sounds.json). Только клиент. */
public final class RWSounds {
    private RWSounds() {}

    private static SoundEvent make(String name) {
        return SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(RealWeather.MODID, name));
    }

    public static final SoundEvent TORNADO_WIND = make("tornado_wind");
    public static final SoundEvent THUNDER_CLOSE = make("thunder_close");
    public static final SoundEvent THUNDER_MID = make("thunder_mid");
    public static final SoundEvent THUNDER_FAR = make("thunder_far");
}
